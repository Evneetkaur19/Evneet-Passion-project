﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ReadersHeaven_1.Startup))]
namespace ReadersHeaven_1
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
