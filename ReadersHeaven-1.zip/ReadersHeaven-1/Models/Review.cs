﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ReadersHeaven_1.Models
{
    public class Review
    {
        [Key]
        public int ReviewId { get; set; }
        public int UserId { get; set; }
        public int BookId { get; set; }
        public string Comments { get; set; }
        public int Reviews { get; set; }
    }
    public class ReviewDto
    {
        [Key]

        public int ReviewId { get; set; }
        public int UserId { get; set; }
        public int BookId { get; set; }
        public string Comments { get; set; }
        public int Reviews { get; set; }

    }
}