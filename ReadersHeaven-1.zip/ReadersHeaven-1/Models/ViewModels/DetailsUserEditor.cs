﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ReadersHeaven_1.Models.ViewModels
{
    public class DetailsUserEditor
    {
        public UserEditorDto SelectedUserEditor { get; set; }
        public IEnumerable<UserEditorDto> KeptBooks { get; set; }
        public IEnumerable<BookDto> EditedBooks { get; set; }
        
    }
}