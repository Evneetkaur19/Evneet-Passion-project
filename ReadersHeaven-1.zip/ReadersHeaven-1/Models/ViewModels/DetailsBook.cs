﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ReadersHeaven_1.Models.ViewModels
{
    public class DetailsBook
    {
        public BookDto SelectedBook { get; set; }
        public IEnumerable<BookDto> AvailableBooks { get; set; }
         public IEnumerable<BookDto> RelatedBooks { get; set; }
        public IEnumerable<BookDto> EditedBooks { get; set; }
    }
}
