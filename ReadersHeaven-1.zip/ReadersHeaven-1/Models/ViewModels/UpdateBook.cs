﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ReadersHeaven_1.Models.ViewModels
{
    public class UpdateBook
    {
        public BookDto SelectedBook { get; set; }

        // all reviews to choose from when updating this book

        public IEnumerable<ReviewDto> ReviewOptions { get; set; }
    }
}