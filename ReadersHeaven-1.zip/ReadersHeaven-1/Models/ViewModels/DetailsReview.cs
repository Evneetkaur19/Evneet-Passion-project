﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ReadersHeaven_1.Models.ViewModels
{
    public class DetailsReview
    {
        public ReviewDto SelectedReview { get; set; }

        public IEnumerable<BookDto> RelatedBooks { get; set; }

    }
}