﻿using ReadersHeaven_1.Migrations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Policy;
using System.Web;

namespace ReadersHeaven_1.Models
{
    public class Book
    {
        [Key]
        public int BookId { get; set; }
        [ForeignKey("UserEditor")]
        public int UserId { get; set; }
        public virtual UserEditor UserEditor { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public int Review { get; set; }

        //One book can have multiple reviews
        public virtual ICollection<Review> review { get; set; }
    }
    public class BookDto
    {
        public int BookId { get; set; }
        public int UserId { get; set; }
        public int UserEditor {  get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public int Review { get; set; }
    }


}
