﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using ReadersHeaven_1.Models;
using ReadersHeaven_1.Models.ViewModels;

namespace ReadersHeaven_1.Controllers
{
    public class UserEditorController : Controller
    {
        private static readonly HttpClient client;
        private JavaScriptSerializer jss = new JavaScriptSerializer();

        static UserEditorController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44324/api/");
        }

        // GET: UserEditor/List
        public ActionResult List()
        {
            string url = "UserEditorData/ListUserEditors";
            HttpResponseMessage response = client.GetAsync(url).Result;

            IEnumerable<UserEditorDto> UserEditors = response.Content.ReadAsAsync<IEnumerable<UserEditorDto>>().Result;

            return View(UserEditors);
        }

        public ActionResult Details(int id)
        {
            DetailsUserEditor ViewModel = new DetailsUserEditor();

            string url = "UserEditorData/FindUserEditor/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;

            UserEditorDto SelectedUserEditor = response.Content.ReadAsAsync<UserEditorDto>().Result;

            ViewModel.SelectedUserEditor = SelectedUserEditor;

            url = "BookData/ListBooksForUserEditor/" + id;
            response = client.GetAsync(url).Result;
            IEnumerable<BookDto> EditedBooks = response.Content.ReadAsAsync<IEnumerable<BookDto>>().Result;

            ViewModel.EditedBooks = EditedBooks;

            return View(ViewModel);
        }

        public ActionResult Error()
        {
            return View();
        }

        public ActionResult New()
        {
            return View();
        }

        // POST: UserEditor/Create
        [HttpPost]
        public ActionResult Create(UserEditor UserEditor)
        {
            string url = "UserEditorData/AddUserEditor";

            string jsonpayload = jss.Serialize(UserEditor);

            HttpContent content = new StringContent(jsonpayload);
            content.Headers.ContentType.MediaType = "application/json";

            HttpResponseMessage response = client.PostAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Error");
            }
        }

        public ActionResult Edit(int id)
        {
            string url = "UserEditorData/FindUserEditor/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;
            UserEditorDto selectedUserEditor = response.Content.ReadAsAsync<UserEditorDto>().Result;
            return View(selectedUserEditor);
        }

        // POST: UserEditor/Update/5
        [HttpPost]
        public ActionResult Update(int id, UserEditor UserEditor)
        {
            string url = "UserEditorData/UpdateUserEditor/" + id;
            string jsonpayload = jss.Serialize(UserEditor);
            HttpContent content = new StringContent(jsonpayload);
            content.Headers.ContentType.MediaType = "application/json";
            HttpResponseMessage response = client.PostAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Error");
            }
        }

        // GET: UserEditor/Delete/5
        public ActionResult DeleteConfirm(int id)
        {
            string url = "UserEditorData/FindUserEditor/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;
            UserEditorDto selectedUserEditor = response.Content.ReadAsAsync<UserEditorDto>().Result;
            return View(selectedUserEditor);
        }

        // POST: UserEditor/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {
            string url = "UserEditorData/DeleteUserEditor/" + id;
            HttpContent content = new StringContent("");
            content.Headers.ContentType.MediaType = "application/json";
            HttpResponseMessage response = client.PostAsync(url, content).Result;

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Error");
            }
        }
    }
}
