﻿using ReadersHeaven_1.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace ReadersHeaven_1.Controllers
{
    public class UserEditorDataController : ApiController
    {
            private ApplicationDbContext db = new ApplicationDbContext();

            [HttpGet]
            [ResponseType(typeof(UserEditorDto))]
            public IHttpActionResult ListUserEditors()
            {
                List<UserEditor> UserEditors = db.UserEditor.ToList();
                List<UserEditorDto> UserEditorDtos = new List<UserEditorDto>();

                UserEditors.ForEach(u => UserEditorDtos.Add(new UserEditorDto()
                {
                    UserId = u.UserId,
                    Username = u.Username
                }));

                return Ok(UserEditorDtos);
            }

            [HttpGet]
            [ResponseType(typeof(UserEditorDto))]
            public IHttpActionResult ListUserEditorsForBook(int id)
            {

                List<UserEditor> UserEditors = db.UserEditor.Where(
                    u => u.Books.Any(
                        b => b.BookId == id)
                    ).ToList();
                List<UserEditorDto> UserEditorDtos = new List<UserEditorDto>();

                UserEditors.ForEach(u => UserEditorDtos.Add(new UserEditorDto()
                {
                    UserId = u.UserId,
                    Username = u.Username
                }));

                return Ok(UserEditorDtos);
            }

            [HttpGet]
            [ResponseType(typeof(UserEditorDto))]
            public IHttpActionResult ListUserEditorsNotEditingBook(int id)
            {
                List<UserEditor> UserEditors = db.UserEditor.Where(
                    u => !u.Books.Any(
                        b => b.BookId == id)
                    ).ToList();
                List<UserEditorDto> UserEditorDtos = new List<UserEditorDto>();

                UserEditors.ForEach(u => UserEditorDtos.Add(new UserEditorDto()
                {
                    UserId = u.UserId,
                    Username = u.Username
                }));

                return Ok(UserEditorDtos);
            }

            [ResponseType(typeof(UserEditorDto))]
            [HttpGet]
            public IHttpActionResult FindUserEditor(int id)
            {
                UserEditor UserEditor = db.UserEditor.Find(id);
                if (UserEditor == null)
                {
                    return NotFound();
                }

                UserEditorDto UserEditorDto = new UserEditorDto()
                {
                    UserId = UserEditor.UserId,
                    Username = UserEditor.Username
                };

                return Ok(UserEditorDto);
            }

            [ResponseType(typeof(void))]
            [HttpPost]
            public IHttpActionResult UpdateUserEditor(int id, UserEditor UserEditor)
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                if (id != UserEditor.UserId)
                {
                    return BadRequest();
                }

                db.Entry(UserEditor).State = EntityState.Modified;

                try
                {
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserEditorExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return StatusCode(HttpStatusCode.NoContent);
            }

            [ResponseType(typeof(UserEditor))]
            [HttpPost]
            public IHttpActionResult AddUserEditor(UserEditor UserEditor)
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                db.UserEditor.Add(UserEditor);
                db.SaveChanges();

                return CreatedAtRoute("DefaultApi", new { id = UserEditor.UserId }, UserEditor);
            }

            [ResponseType(typeof(UserEditor))]
            [HttpPost]
            public IHttpActionResult DeleteUserEditor(int id)
            {
                UserEditor UserEditor = db.UserEditor.Find(id);
                if (UserEditor == null)
                {
                    return NotFound();
                }

                db.UserEditor.Remove(UserEditor);
                db.SaveChanges();

                return Ok();
            }

            protected override void Dispose(bool disposing)
            {
                if (disposing)
                {
                    db.Dispose();
                }
                base.Dispose(disposing);
            }

            private bool UserEditorExists(int id)
            {
                return db.UserEditor.Count(e => e.UserId == id) > 0;
            }
        }
    }

}
}
