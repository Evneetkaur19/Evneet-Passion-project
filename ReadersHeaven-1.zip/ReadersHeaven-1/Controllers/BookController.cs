﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using ReadersHeaven_1.Models;
using ReadersHeaven_1.Models.ViewModels;

namespace ReadersHeaven_1.Controllers
{
    public class BookController : Controller
    {
        private static readonly HttpClient client;
        private JavaScriptSerializer jss = new JavaScriptSerializer();

        static BookController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44324/api/");
        }

        // GET: Book/List
        public ActionResult List()
        {
            string url = "BookData/ListBooks";
            HttpResponseMessage response = client.GetAsync(url).Result;

            IEnumerable<BookDto> books = response.Content.ReadAsAsync<IEnumerable<BookDto>>().Result;
            return View(books);
        }

        // GET: Book/Details/5
        public ActionResult Details(int id)
        {
            DetailsBook ViewModel = new DetailsBook();

            string url = "BookData/FindBook/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;

            Debug.WriteLine("The response code is ");
            Debug.WriteLine(response.StatusCode);

            BookDto SelectedBook = response.Content.ReadAsAsync<BookDto>().Result;
            Debug.WriteLine("Book received : ");
            Debug.WriteLine(SelectedBook.Title);

            ViewModel.SelectedBook = SelectedBook;

            return View(ViewModel);
        }

        //POST: Book/Associate/{BookId}/{UserId}
        [HttpPost]
        public ActionResult Associate(int id, int UserId)
        {
            Debug.WriteLine("Attempting to associate book :" + id + " with user " + UserId);

            string url = "BookData/AssociateBookWithUserEditor/" + id + "/" + UserId;
            HttpContent content = new StringContent("");
            content.Headers.ContentType.MediaType = "application/json";
            HttpResponseMessage response = client.PostAsync(url, content).Result;

            return RedirectToAction("Details/" + id);
        }

        //Get: Book/UnAssociate/{id}?UserId={UserId}
        [HttpGet]
        public ActionResult UnAssociate(int id, int UserId)
        {
            Debug.WriteLine("Attempting to unassociate book :" + id + " with user: " + UserId);

            string url = "BookData/UnAssociateBookWithUserEditor/" + id + "/" + UserId;
            HttpContent content = new StringContent("");
            content.Headers.ContentType.MediaType = "application/json";
            HttpResponseMessage response = client.PostAsync(url, content).Result;

            return RedirectToAction("Details/" + id);
        }

        public ActionResult Error()
        {
            return View();
        }

        // GET: Book/New
        public ActionResult New()
        {
            return View();
        }

        // POST: Book/Create
        [HttpPost]
        public ActionResult Create(Book book)
        {
            Debug.WriteLine("the json payload is :");
            string url = "BookData/AddBook";

            string jsonpayload = jss.Serialize(book);
            Debug.WriteLine(jsonpayload);

            HttpContent content = new StringContent(jsonpayload);
            content.Headers.ContentType.MediaType = "application/json";

            HttpResponseMessage response = client.PostAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Error");
            }
        }

        // GET: Book/Edit/5
        public ActionResult Edit(int id)
        {
            UpdateBook ViewModel = new UpdateBook();

            string url = "BookData/FindBook/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;
            BookDto SelectedBook = response.Content.ReadAsAsync<BookDto>().Result;
            ViewModel.SelectedBook = SelectedBook;

            return View(ViewModel);
        }

        // POST: Book/Update/5
        [HttpPost]
        public ActionResult Update(int id, Book book)
        {
            string url = "BookData/UpdateBook/" + id;
            string jsonpayload = jss.Serialize(book);
            HttpContent content = new StringContent(jsonpayload);
            content.Headers.ContentType.MediaType = "application/json";
            HttpResponseMessage response = client.PostAsync(url, content).Result;
            Debug.WriteLine(content);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Error");
            }
        }

        // GET: Book/DeleteConfirm/5
        public ActionResult DeleteConfirm(int id)
        {
            string url = "BookData/FindBook/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;
            BookDto selectedBook = response.Content.ReadAsAsync<BookDto>().Result;
            return View(selectedBook);
        }

        // POST: Book/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {
            string url = "BookData/DeleteBook/" + id;
            HttpContent content = new StringContent("");
            content.Headers.ContentType.MediaType = "application/json";
            HttpResponseMessage response = client.PostAsync(url, content).Result;

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Error");
            }
        }
    }
}
