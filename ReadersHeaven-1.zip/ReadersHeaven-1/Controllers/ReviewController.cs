﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Web.Mvc;
using ReadersHeaven_1.Models;
using ReadersHeaven_1.Models.ViewModels;
using System.Web.Script.Serialization;

namespace ReadersHeaven_1.Controllers
{
    public class ReviewController : Controller
    {
        private static readonly HttpClient client;
        private JavaScriptSerializer jss = new JavaScriptSerializer();

        static ReviewController()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44324/api/");
        }

        // GET: Review/List
        public ActionResult List()
        {
            //objective: communicate with our Review data api to retrieve a list of Reviews
            //curl https://localhost:44324/api/reviewdata/listreviews

            string url = "reviewdata/listreviews";
            HttpResponseMessage response = client.GetAsync(url).Result;

            //Debug.WriteLine("The response code is ");
            //Debug.WriteLine(response.StatusCode);

            IEnumerable<ReviewDto> reviews = response.Content.ReadAsAsync<IEnumerable<ReviewDto>>().Result;
            //Debug.WriteLine("Number of reviews received : ");
            //Debug.WriteLine(reviews.Count());

            return View(reviews);
        }

        // GET: Review/Details/5
        public ActionResult Details(int id)
        {
            //objective: communicate with our Review data api to retrieve one review
            //curl https://localhost:44324/api/reviewdata/findreview/{id}

            DetailsReview ViewModel = new DetailsReview();

            string url = "reviewdata/findreview/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;

            Debug.WriteLine("The response code is ");
            Debug.WriteLine(response.StatusCode);

            ReviewDto SelectedReview = response.Content.ReadAsAsync<ReviewDto>().Result;
            Debug.WriteLine("Review received : ");
            Debug.WriteLine(SelectedReview.ReviewId);

            ViewModel.SelectedReview = SelectedReview;

            //showcase information about books related to this review
            //send a request to gather information about books related to a particular review ID
            url = "bookdata/listbooksforreview/" + id;
            response = client.GetAsync(url).Result;
            IEnumerable<BookDto> RelatedBooks = response.Content.ReadAsAsync<IEnumerable<BookDto>>().Result;

            ViewModel.RelatedBooks = RelatedBooks;

            return View(ViewModel);
        }

        public ActionResult Error()
        {
            return View();
        }

        // GET: Review/New
        public ActionResult New()
        {
            return View();
        }

        // POST: Review/Create
        [HttpPost]
        public ActionResult Create(Review review)
        {
            Debug.WriteLine("the json payload is :");
            //Debug.WriteLine(review.ReviewText);
            //objective: add a new review into our system using the API
            //curl -H "Content-Type:application/json" -d @review.json https://localhost:44324/api/reviewdata/addreview 
            string url = "reviewdata/addreview";

            string jsonpayload = jss.Serialize(review);
            Debug.WriteLine(jsonpayload);

            HttpContent content = new StringContent(jsonpayload);
            content.Headers.ContentType.MediaType = "application/json";

            HttpResponseMessage response = client.PostAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Error");
            }
        }

        // GET: Review/Edit/5
        public ActionResult Edit(int id)
        {
            string url = "reviewdata/findreview/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;
            ReviewDto selectedReview = response.Content.ReadAsAsync<ReviewDto>().Result;
            return View(selectedReview);
        }

        // POST: Review/Update/5
        [HttpPost]
        public ActionResult Update(int id, Review review)
        {
            string url = "reviewdata/updatereview/" + id;
            string jsonpayload = jss.Serialize(review);
            HttpContent content = new StringContent(jsonpayload);
            content.Headers.ContentType.MediaType = "application/json";
            HttpResponseMessage response = client.PostAsync(url, content).Result;
            Debug.WriteLine(content);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Error");
            }
        }

        // GET: Review/Delete/5
        public ActionResult DeleteConfirm(int id)
        {
            string url = "reviewdata/findreview/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;
            ReviewDto selectedReview = response.Content.ReadAsAsync<ReviewDto>().Result;
            return View(selectedReview);
        }

        // POST: Review/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {
            string url = "reviewdata/deletereview/" + id;
            HttpContent content = new StringContent("");
            content.Headers.ContentType.MediaType = "application/json";
            HttpResponseMessage response = client.PostAsync(url, content).Result;

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("List");
            }
            else
            {
                return RedirectToAction("Error");
            }
        }
    }
}
