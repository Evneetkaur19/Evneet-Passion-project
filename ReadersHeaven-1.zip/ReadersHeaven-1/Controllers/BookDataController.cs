﻿using ReadersHeaven_1.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace ReadersHeaven_1.Controllers
{
    public class BookDataController : ApiController
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        [HttpGet]
        [ResponseType(typeof(BookDto))]
        public IHttpActionResult ListBooks()
        {
            List<Book> Books = db.Book.ToList(); 
            List<BookDto> BookDtos = new List<BookDto>();

            Books.ForEach(b => BookDtos.Add(new BookDto()
            {
                BookId = b.BookId,
                UserId = b.UserId,
                Title = b.Title,
                Author = b.Author,
                Review = b.Review,
            }));

            return Ok(BookDtos);
        }

        [HttpPost]
        [Route("api/BookData/AssociateBookWithUserEditor/{BookId}/{UserId}")]
        public IHttpActionResult AssociateBookWithUserEditor(int BookId, int UserId)
        {
            Book SelectedBook = db.Book.Include(u => u.UserEditor).Where(u => u.BookId == BookId).FirstOrDefault();
            UserEditor SelectedUserEditor = db.UserEditor.Find(UserId);

            if (SelectedBook == null || SelectedUserEditor == null)
            {
                return NotFound();
            }

            Debug.WriteLine("input Book id is: " + BookId);
            Debug.WriteLine("selected Book Title is: " + SelectedBook.Title);
            Debug.WriteLine("input UserId is: " + UserId);
            Debug.WriteLine("selected UserEditor name is: " + SelectedUserEditor.Username);

            SelectedBook.UserEditor = SelectedUserEditor;
            db.SaveChanges();
            SelectedUserEditor.UserId= UserId;
            db.SaveChanges();

            return Ok();
        }

        [HttpPost]
        [Route("api/BookData/UnAssociateBookWithUserEditor/{BookId}/{UserId}")]
        public IHttpActionResult UnAssociateBookWithUserEditor(int BookId, int UserId)
        {
            Book SelectedBook = db.Book.Include(u => u.UserEditor).Where(b => b.BookId == BookId).FirstOrDefault();
            UserEditor SelectedUserEditor = db.UserEditor.Find(UserId);

            if (SelectedBook == null || SelectedUserEditor == null)
            {
                return NotFound();
            }

            Debug.WriteLine("input BookId is: " + BookId);
            Debug.WriteLine("selected Book title is: " + SelectedBook.Title);
            Debug.WriteLine("input UserId is: " + UserId);
            Debug.WriteLine("selected UserEditor name is: " + SelectedUserEditor.Username);

            if (SelectedBook.UserEditor.UserId == UserId)
            {
                SelectedBook.UserEditor = null;
                SelectedUserEditor.UserId = UserId;
                db.SaveChanges();
            }

            return Ok();
        }

        [ResponseType(typeof(BookDto))]
        [HttpGet]
        public IHttpActionResult FindBook(int id)
        {
            Book Book = db.Book.Include(b => b.UserEditor).Where(b => b.BookId == id).FirstOrDefault();
            if (Book == null)
            {
                return NotFound();
            }

            BookDto BookDto = new BookDto()
            {
                BookId = Book.BookId,
                UserId = Book.UserId,
                Title = Book.Title,
                Author = Book.Author,
                Review = Book.Review
            };

            return Ok(BookDto);
        }

        [ResponseType(typeof(void))]
        [HttpPost]
        public IHttpActionResult UpdateBook(int id, Book book)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != book.BookId)
            {
                return BadRequest();
            }

            db.Entry(book).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BookExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }

        [ResponseType(typeof(Book))]
        [HttpPost]
        public IHttpActionResult AddBook(Book book)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Book.Add(book);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = book.BookId }, book);
        }

        [ResponseType(typeof(Book))]
        [HttpPost]
        public IHttpActionResult DeleteBook(int id)
        {
            Book book = db.Book.Find(id);
            if (book == null)
            {
                return NotFound();
            }

            db.Book.Remove(book);
            db.SaveChanges();

            return Ok();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool BookExists(int id)
        {
            return db.Book.Count(e => e.BookId == id) > 0;
        }
    }
}
