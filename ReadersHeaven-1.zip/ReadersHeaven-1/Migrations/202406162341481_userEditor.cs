﻿namespace ReadersHeaven_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class userEditor : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.UserEditors",
                c => new
                    {
                        UserId = c.Int(nullable: false, identity: true),
                        Username = c.String(),
                        Email = c.String(),
                        Password = c.String(),
                        Bio = c.String(),
                    })
                .PrimaryKey(t => t.UserId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.UserEditors");
        }
    }
}
