﻿namespace ReadersHeaven_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ReviewsBooks : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ReviewsBooks",
                c => new
                    {
                        Reviews_ReviewId = c.Int(nullable: false),
                        Books_BookId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Reviews_ReviewId, t.Books_BookId })
                .ForeignKey("dbo.Reviews", t => t.Reviews_ReviewId, cascadeDelete: true)
                .ForeignKey("dbo.Books", t => t.Books_BookId, cascadeDelete: true)
                .Index(t => t.Reviews_ReviewId)
                .Index(t => t.Books_BookId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ReviewsBooks", "Books_BookId", "dbo.Books");
            DropForeignKey("dbo.ReviewsBooks", "Reviews_ReviewId", "dbo.Reviews");
            DropIndex("dbo.ReviewsBooks", new[] { "Books_BookId" });
            DropIndex("dbo.ReviewsBooks", new[] { "Reviews_ReviewId" });
            DropTable("dbo.ReviewsBooks");
        }
    }
}
